Cufon.replace('.ambitios_title, .ambitios_footer_widget, .ambitios_sleder_title, h1', { fontFamily: 'Quicksand Bold' });
Cufon.replace('h2, h3', { fontFamily: 'Quicksand Book' });